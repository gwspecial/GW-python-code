#######################################################################
# [gwInit.py]
#   初期化制御
#######################################################################

import sys
import threading
import time

from collections import OrderedDict

from socket import timeout
import os
import datetime

from comm import const
from comm import gwComm
from comm import monitorlog
from Mqtt import gwMqtt

#######################################################################
# 時刻取得
#######################################################################
def getTime():
	ret = False
	res = False
	getdata = False
	return True

	data = ''
	data_5 = ['','','','','']
	date_com = ''
	time_Current = True

	for i in range(5):
		cmd = 'mmcli -m 0 --time | grep Current'
		gwComm.logger.debug(cmd)
		
		time.sleep(0.5)

		try:
			with os.popen(cmd) as fs:
				data = fs.read()
		except Exception as e:
			gwComm.logger.debug(e)

		if (data == ""):
			cmd = 'mmcli -m 0 --time | grep current'
			gwComm.logger.debug(cmd)
			
			time.sleep(0.5)
			
			try:
				with os.popen(cmd) as fs:
					data = fs.read()
			except Exception as e:
				gwComm.logger.debug(e)
			
			# Currentではなくcurrentを実行
			time_Current = False

		if (data == ""):
			# 取得できない
			# ログ出力
			func_name = sys._getframe().f_code.co_name
			line_no = str(sys._getframe().f_lineno)

			mess = gwComm.const.SOFT_ERROR + ' '+ func_name + ':' + line_no + ':Do not get time'
			monitorlog.monitorLog(2, mess)
			
		else:
			# 時刻設定
			td = data.split()

			key = td[3].split('+')

			try:
				if time_Current == True:
					time_data = datetime.datetime.strptime(key[0], '\'%Y-%m-%dT%H:%M:%S')
				else:
					time_data = datetime.datetime.strptime(key[0], '%Y-%m-%dT%H:%M:%S')
				year = format(time_data.year, '04')
				month = format(time_data.month, '02')
				day = format(time_data.day, '02')
				hour = format(time_data.hour, '02')
				min = format(time_data.minute, '02')
				sec = format(time_data.second, '02')

				date_com = 'date '+month+day+hour+min+year+'.'+sec
				
				data_5[i]=year+month+day+hour+min
				
				res = True

			except Exception as e:
				# ログ出力
				func_name = sys._getframe().f_code.co_name
				line_no = str(sys._getframe().f_lineno)

				mess = gwComm.const.SOFT_ERROR + ' '+ func_name + ':' + line_no + ':' + str(e)
				monitorlog.monitorLog(2, mess)

				gwComm.logger.debug(str(e))
				res = False

				break

	# 時刻情報5件取得できた場合
	if res == True:
		for i in range(4):
			if data_5[i] == data_5[i+1]:
				getdata = True
			else:
				getdata = False
				func_name = sys._getframe().f_code.co_name
				line_no = str(sys._getframe().f_lineno)
				mess = gwComm.const.SOFT_ERROR + ' '+ func_name + ':' + line_no + ':' + data_5[i] + ' : ' + data_5[i+1]
				monitorlog.monitorLog(2, mess)
				break

	# 時刻情報5件全て一致した場合、時刻の設定処理を行う
	if getdata == True:
		gwComm.logger.debug(date_com)
		os.system(date_com)
		ret = True

	return ret

#######################################################################
# 起動時設定
#######################################################################
def setStartupDate():
	"""
	parameters
	----------
		none

	returns
	-------
		none
	"""

	# リトライカウンタ 初期化
	date_retry = 0
	date_flg = False

	func_name = sys._getframe().f_code.co_name
	line_no = str(sys._getframe().f_lineno)
	mess = func_name + ':' + line_no
	monitorlog.monitorLog(0, mess)

	while True:
		# 時刻取得
		date_flg = getTime()

		if (date_flg == True):
			# 時刻設定
			break
