#!/usr/bin/python3
#######################################################################
# [MainProc.py]
#######################################################################

import sys
import os
import threading
import subprocess

from Init import gwInit
from comm import gwComm
from comm import monitorlog
from Mqtt import gwMqtt

#######################################################################
# getSerialNo() シリアル番号取得
#######################################################################
def getSerialNo():

	cmd = """hexdump -v -s 0xa0 -n 8 -e '/4 "%08X"' /sys/bus/nvmem/devices/imx-ocotp0/nvmem | cut -c 5-"""
	ret = subprocess.run(cmd, shell=True,capture_output=True,encoding='utf-8')
	no = ret.stdout.rstrip()
	return no

#######################################################################
# main() メイン関数
#######################################################################
def main():

	monitorlog.monitorOpenLog()

	func_name = sys._getframe().f_code.co_name
	line_no = str(sys._getframe().f_lineno)
	mess = gwComm.const.PROCESS_START + ' '+ func_name + ':' + line_no
	monitorlog.monitorLog(0, mess)

	try:
	    with os.popen("ln -sf /usr/share/zoneinfo/Asia/Tokyo /etc/localtime") as fs:
	        data = fs.read()
	except Exception as e:
	    gwComm.logger.debug(e)

	gwComm.serial_no = getSerialNo()

	if (gwComm.serial_no == ""):
		func_name = sys._getframe().f_code.co_name
		line_no = str(sys._getframe().f_lineno)
		mess = gwComm.const.SOFT_ERROR + ' '+ func_name + ':' + line_no + ':Cannot Start up'
		monitorlog.monitorLog(2, mess)
	else:
		try:
			threads=[]

			gwInit.setStartupDate()

			mqtt_recv_id = gwMqtt.recvMain()
			threads.append(mqtt_recv_id)

			for therads_id in threads:
				therads_id.start()

			for therads_id in threads:
				therads_id.join()

			func_name = sys._getframe().f_code.co_name
			line_no = str(sys._getframe().f_lineno)
			mess = gwComm.const.PROCESS_STOP + ' '+ func_name + ':' + line_no
			monitorlog.monitorLog(0, mess)

		except Exception as e:
			func_name = sys._getframe().f_code.co_name
			line_no = str(sys._getframe().f_lineno)
			mess = gwComm.const.SOFT_ERROR + ' '+ func_name + ':' + line_no
			monitorlog.monitorLog(2, mess)

if __name__ == "__main__":
	main()
