import time
import syslog
import os

#######################################################################
# syslogOpen処理
#######################################################################
def monitorOpenLog():
	syslog.openlog('Brick Device',syslog.LOG_PID)

#######################################################################
# syslog送信処理
#######################################################################
def monitorLog(no,msg):
	if no == 0:
		syslog.syslog(syslog.LOG_INFO,msg)
	elif no == 1:
		syslog.syslog(syslog.LOG_NOTICE,msg)
	else:
		syslog.syslog(syslog.LOG_ERR,msg)

#######################################################################
# syslogClose処理
#######################################################################
def monitorCloseLog():
    syslog.closelog();
