####################################################################
# [gwComm.py]
#    共通処理
####################################################################
#!/usr/bin/python3

import ruamel.yaml
from logging import config,getLogger
import threading
import queue
import time
import os

from comm import const

#######################################################################
# BLE最大数
#######################################################################
const.BLE_MAX = 16

#######################################################################
# メッセージ
#######################################################################
class gwMessage:
	topic_str = ""
	mess_str = ""

serial_no = ""

LOGCONF_FILE = "/home/GWBt/Config/logconf.yml"
config.dictConfig(ruamel.yaml.YAML().load(open(LOGCONF_FILE, encoding='UTF-8').read()))
logger = getLogger()

const.PROCESS_START = "Process Starting"
const.PROCESS_STOP = "Process Stoping"
const.SOFT_ERROR = "Soft ERR"
