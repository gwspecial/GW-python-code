####################################################################
# [gwMqtt.py]
#    MQTT 通信制御
####################################################################
#!/usr/bin/python3
import sys
import threading
import queue
import time
import datetime
import json
import paho.mqtt.client as mqtt
from collections import OrderedDict
import ssl
import os
import glob
import re
import requests
import ruamel.yaml

from comm import const
from comm import gwComm
from comm import monitorlog
from Init import gwInit
from Mqtt import gwMqtt

patlump_mac = []
patlump_ip  = []
g_topic = []
const.PATLAMYML = "/var/app/volumes/patlamp.yml"

#######################################################################
# MQTT初期化処理
#######################################################################
g_mqtt = mqtt.Client()

def mqttSend(topic, json_data):
	global g_mqtt
	try:
		mqtt_qos = 1
		res = False
		gwComm.logger.debug('qos  : %d', mqtt_qos)
		gwComm.logger.debug("topic : %s  json : %s", topic, json_data)
		g_mqtt.publish(topic, json_data, qos=mqtt_qos)
		res = True

		del json_data
		del mqtt_qos

	except Exception as e:
		func_name = sys._getframe().f_code.co_name
		line_no = str(sys._getframe().f_lineno)
		mess = gwComm.const.SOFT_ERROR + ' '+ func_name + ':' + line_no + ':Do not MQTT connect'
		monitorlog.monitorLog(2, mess)
		del mess
		res = False

	return res

#######################################################################
# MQTT接続処理
#######################################################################
def on_connect(client, userdata, flags, respons_code):
	global g_topic
	global g_patlump_num
	gwComm.logger.debug(respons_code)

	func_name = sys._getframe().f_code.co_name
	line_no = str(sys._getframe().f_lineno)
	mess = 'MQTT CONNECT '+ func_name + ':' + line_no
	monitorlog.monitorLog(0, mess)

	for i in range(g_patlump_num):
		client.subscribe(g_topic[i])
		gwComm.logger.debug(g_topic[i])


#######################################################################
# disconnect の情報
#######################################################################
def on_disconnect_sub(client, userdata, flag):
	gwComm.logger.debug(userdata)
	gwComm.logger.debug(flag)

#######################################################################
# publish の情報
#######################################################################
def on_publish(client, userdata, mid):
	gwComm.logger.debug(mid)

def on_message(client, userdata, message):
	gwComm.logger.debug(message.topic)
	gwComm.logger.debug(message.qos)
	try:
		json_text = json.loads(message.payload)
		gwComm.logger.debug(json_text)
	except Exception as e:
		gwComm.logger.debug(e)

	url = ''
	topic = ''
	for i in range(g_patlump_num):
		if ( json_text['device_id'] == patlump_mac[i] ):
			url = 'http://' + patlump_ip[i] + '/api/control'
			topic = 'brickeiot/devices/' + patlump_mac[i] + '/response'
			gwComm.logger.debug(url)
			gwComm.logger.debug(topic)
			break

	if ( url == '' ):
		gwComm.logger.debug("url_none")
		func_name = sys._getframe().f_code.co_name
		line_no = str(sys._getframe().f_lineno)
		mess = gwComm.const.SOFT_ERROR + ' '+ func_name + ':' + line_no + ':url none'
		monitorlog.monitorLog(2, mess)

	if ( url != '' ):
		if ( json_text['status']=="error"):
			gwComm.logger.debug("error")
			params = {"alert": "200001"}
		if ( json_text['status']=="normal"):
			gwComm.logger.debug("normal")
			params = {"alert": "001000"}
		if ( json_text['status']=="ignore"):
			gwComm.logger.debug("alert")
			params = {"alert": "010000"}
		try:
			response = requests.get(url, params=params, timeout=(3.0, 7.5))
			gwComm.logger.debug(response.status_code)
			gwComm.logger.debug(response.text)
			if ( response.text == "Success." ):
				result = True
			else:
				result = False
		except Exception as e:
			func_name = sys._getframe().f_code.co_name
			line_no = str(sys._getframe().f_lineno)
			mess = gwComm.const.SOFT_ERROR + ' '+ func_name + ':' + line_no + ':HTTP Error'
			monitorlog.monitorLog(2, mess)
			result = False
		data_python = {'request_id': json_text['request_id'],
						'device_id': json_text['device_id'],
						'is_done': result
		}

	if ( topic != '' ):
		try:
			data_json = json.dumps(data_python)
			mqttSend(topic, data_json)
		except Exception as e:
			gwComm.logger.debug(e)
			func_name = sys._getframe().f_code.co_name
			line_no = str(sys._getframe().f_lineno)
			mess = gwComm.const.SOFT_ERROR + ' '+ func_name + ':' + line_no + ':MQTT Send'
			monitorlog.monitorLog(2, mess)

def recvThread():
	global g_mqtt
	global g_topic
	global g_patlump_num

	g_patlump_num = 0
	if (os.path.exists(const.PATLAMYML)):
		try:
			with open(const.PATLAMYML, 'r') as yml:
				yaml = ruamel.yaml.YAML()
				spec_list = yaml.load(yml)
				patlump_mac.clear()
				patlump_ip.clear()
				for i in range(0, len(spec_list)):
					tmp = re.split('[: \"\']',spec_list[i])
					patlump_mac.append(tmp[4])
					patlump_ip.append(tmp[8])
					g_patlump_num += 1

		except Exception as e:
			gwComm.logger.debug(e)
			func_name = sys._getframe().f_code.co_name
			line_no = str(sys._getframe().f_lineno)
			mess = gwComm.const.SOFT_ERROR + ' '+ func_name + ':' + line_no + ':Yaml ERR'
			monitorlog.monitorLog(2, mess)

	host = '192.168.0.1'
	port = 8883
	
	
	for i in range(g_patlump_num):
		g_topic.append('brickeiot/devices/' + patlump_mac[i] + '/request')

	cacert = "RootCA1.pem"
	clientCert = "certificate.pem.crt"
	clientKey = "private.pem.key"

	g_mqtt = mqtt.Client()

	g_mqtt.on_connect = on_connect
	g_mqtt.on_message = on_message
	g_mqtt.on_publish = on_publish	

	g_mqtt.tls_set(cacert, certfile = clientCert,
				   keyfile = clientKey, tls_version = ssl.PROTOCOL_TLSv1_2)
	g_mqtt.tls_insecure_set(True)

	try:
		g_mqtt.connect(host, port=port, keepalive=120)
	except Exception as e:
		func_name = sys._getframe().f_code.co_name
		line_no = str(sys._getframe().f_lineno)
		mess = gwComm.const.SOFT_ERROR + ' '+ func_name + ':' + line_no + ':g_mqtt.connect NG'
		monitorlog.monitorLog(2, mess)
		del mess

	g_mqtt.loop_start()
	while True:
		time.sleep(1)

def recvMain():
	thread_id = threading.Thread(target=recvThread)
	return thread_id

