####################################################################
# [gwScan.py]
####################################################################
#!/usr/bin/python3
import sys
import threading
import queue
import time
import datetime
import json
import paho.mqtt.client as mqtt
from collections import OrderedDict
import ssl
import os
import glob
import gc
import ast
import urllib.request
import base64
import re
import ruamel.yaml

from comm import const
from comm import gwComm
from comm import monitorlog
from Init import gwInit
from Mqtt import gwMqtt
from bluepy import btle

gateway_no = ""
SERVICE_UUID="55555555-7be2-8066-3df0-cbc0acdba8dd"
CHAR_UUID   ="55555555-7be2-8066-3df0-cbc0acdba8dd"
Event       ="notify"

device      = []

const.BTDEVICEYML = "/var/app/volumes/bt-device.yml"

class MyDelegate(btle.DefaultDelegate):
	global gateway_no
	def __init__(self, params):
		self.addr = params
		btle.DefaultDelegate.__init__(self)

	def handleNotification(self, cHandle, data):
		time_int = int(time.time() * 1000)
		b64encoded = base64.b64encode(data)
		ble_address=self.addr
		ble_add = ble_address.replace(':', '')

		data_python = {'gateway_id': gateway_no,
						'timestamp': time_int,
						'event_type': "notify",
						'bd_address': ble_add,
						'service_uuid': SERVICE_UUID,
						'characteristic_uuid': CHAR_UUID,
						'value': b64encoded.decode()}
		data_json = json.dumps(data_python)
		topic = 'brickeiot/bblegw/' + ble_add +'/uplink'
		gwMqtt.mqttSendMess(topic, data_json)


def bleNetThread(addr):
	global gateway_no

	gateway_no = gwComm.serial_no
	
	while True:
		try:
			peripheral = btle.Peripheral()
			peripheral.connect(addr)
			time.sleep(1)
			peripheral.withDelegate(MyDelegate(addr))

			# Enable Indicate
			peripheral.writeCharacteristic(0x001f, b'\x01\x00')

			TIMEOUT = 60.0
			while True:
				if peripheral.waitForNotifications(TIMEOUT):
					continue

		except Exception as e:
			func_name = sys._getframe().f_code.co_name
			line_no = str(sys._getframe().f_lineno)
			mess = gwComm.const.SOFT_ERROR + ' '+ func_name + ':' + line_no + ':Device Error'
			monitorlog.monitorLog(2, mess)
			time.sleep(2)
		
		time.sleep(2)

def bleNet(addr):
	thread_id2 = threading.Thread(target=bleNetThread,args=(addr,))
	thread_id2.start()
	return thread_id2

def scanThread():
	global device
	gwComm.logger.debug("scanThread Start")
	g_device_num = 0
	if (os.path.exists(const.BTDEVICEYML)):
		try:
			with open(const.BTDEVICEYML, 'r') as yml:
				yaml = ruamel.yaml.YAML()
				spec_list = yaml.load(yml)
				device.clear()
				for i in range(0, len(spec_list)):
					tmp = re.split('[ \"\']',spec_list[i])
					device.append(tmp[3])
					g_device_num += 1
					bleNet(device[i])
		except Exception as e:
			func_name = sys._getframe().f_code.co_name
			line_no = str(sys._getframe().f_lineno)
			mess = gwComm.const.SOFT_ERROR + ' '+ func_name + ':' + line_no + ':Yaml Error'
			monitorlog.monitorLog(2, mess)
			gwComm.logger.debug(e)

	while True:
		time.sleep(60)


def scanMain():
	thread_id = threading.Thread(target=scanThread)
	return thread_id
