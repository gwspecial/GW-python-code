####################################################################
# [gwComm.py]
#    共通処理
####################################################################
#!/usr/bin/python3

import ruamel.yaml
from logging import config,getLogger
import threading
import queue
import time
import os

from comm import const

const.INIT_THREAD_ID = 1
const.SCAN_THREAD_ID = 2
const.NOTIFY_THREAD_ID = 3
const.MQTT_SEND_THREAD_ID = 4

class gwMessage:
	dest_id = 0
	send_id = 0
	mess_id = 0
	topic_str = ""
	mess_str = ""

serial_no = ""

LOGCONF_FILE = "/home/GWBt/Config/logconf.yml"
config.dictConfig(ruamel.yaml.YAML().load(open(LOGCONF_FILE, encoding='UTF-8').read()))
logger = getLogger()

const.PROCESS_START = "Process Starting"
const.PROCESS_STOP = "Process Stoping"
const.SOFT_ERROR = "SOFT Err"
