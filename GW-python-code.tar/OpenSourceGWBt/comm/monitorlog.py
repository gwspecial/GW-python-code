import time
import syslog
import os

def monitorOpenLog():
    syslog.openlog('Brick Device',syslog.LOG_PID)

def monitorLog(no,msg):
    if no == 0:
        syslog.syslog(syslog.LOG_INFO,msg)
    elif no == 1:
        syslog.syslog(syslog.LOG_NOTICE,msg)
    else:
        syslog.syslog(syslog.LOG_ERR,msg)

def monitorCloseLog():
    syslog.closelog();
