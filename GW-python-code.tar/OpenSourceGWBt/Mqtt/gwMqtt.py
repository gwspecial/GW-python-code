####################################################################
# [gwMqtt.py]
#    MQTT 通信制御
####################################################################
#!/usr/bin/python3
import sys
import threading
import queue
import time
import datetime
import json
import paho.mqtt.client as mqtt
from collections import OrderedDict
import ssl
import os
import glob
import gc
import ast
import urllib.request
from comm import const
from comm import gwComm
from comm import monitorlog
from Init import gwInit
from Mqtt import gwMqtt

sendDataQueue = queue.Queue()

lock = threading.Lock()

def on_connect(client, userdata, flags, respons_code):
	gwComm.logger.debug(respons_code)
	func_name = sys._getframe().f_code.co_name
	line_no = str(sys._getframe().f_lineno)
	mess = 'MQTT CONNECT '+ func_name + ':' + line_no
	monitorlog.monitorLog(0, mess)
	gwComm.logger.debug("connect ok")

def on_disconnect_sub(client, userdata, flag):
	gwComm.logger.debug(userdata)
	gwComm.logger.debug(flag)

def on_publish(client, userdata, mid):
	gwComm.logger.debug(mid)

def mqttSend(topic, json_data):
	global g_mqtt

	lock.acquire()

	try:
		mqtt_qos = 1
		res = False
		gwComm.logger.debug('qos  : %d', mqtt_qos)
		gwComm.logger.debug("topic : %s  json : %s", topic, json_data)
		result = g_mqtt.publish(topic, json_data, qos=mqtt_qos)
		status = result[0]

		gwComm.logger.debug("pub ok")
		res = True

		del json_data
		del mqtt_qos

	except Exception as e:
		func_name = sys._getframe().f_code.co_name
		line_no = str(sys._getframe().f_lineno)
		mess = gwComm.const.SOFT_ERROR + ' '+ func_name + ':' + line_no + ':Do not MQTT connect'
		monitorlog.monitorLog(2, mess)
		del mess
		res = False

	lock.release()

	return res


def mqttSendMess(topic, mess):
	item = gwComm.gwMessage()
	item.dest_id = gwComm.const.MQTT_SEND_THREAD_ID
	item.topic_str = topic
	item.mess_str = mess
	sendDataQueue.put(item)
	del item

def do_send_message(item):
	dt_now = datetime.datetime.now()
	res = mqttSend(item.topic_str, item.mess_str)
	del dt_now

def sendThread():
	global mqtt_recv_thread
	gwComm.logger.debug("sendThread Start")

	while True:
		try:
			item = sendDataQueue.get_nowait()
			do_send_message(item)

			del item
		except queue.Empty:
			time.sleep(1)

def sendMain():
	global g_mqtt

	cacert = "RootCA1.pem"
	clientCert = "certificate.pem.crt"
	clientKey = "private.pem.key"

	g_mqtt = mqtt.Client(protocol=mqtt.MQTTv311)

	g_mqtt.on_connect = on_connect
	g_mqtt.on_disonnect = on_disconnect_sub
	g_mqtt.on_publish = on_publish	

	g_mqtt.tls_set(cacert, certfile = clientCert,
				   keyfile = clientKey, tls_version = ssl.PROTOCOL_TLSv1_2)
	g_mqtt.tls_insecure_set(True)
	host = '192.168.0.1'
	port = 8883
	while True:
		try:
			g_mqtt.connect(host, port=port, keepalive=120)
			break
		except queue.Empty:
			time.sleep(1)
	g_mqtt.loop_start()

	thread_id = threading.Thread(target=sendThread)

	return thread_id
